/*    */ package monkey.lumpy.horse.stats.vanilla.gui;
/*    */ import io.github.cottonmc.cotton.gui.client.LightweightGuiDescription;
/*    */ import io.github.cottonmc.cotton.gui.widget.WBox;
/*    */ import io.github.cottonmc.cotton.gui.widget.WLabel;
/*    */ import io.github.cottonmc.cotton.gui.widget.WPanel;
/*    */ import io.github.cottonmc.cotton.gui.widget.WWidget;
/*    */ import io.github.cottonmc.cotton.gui.widget.data.Axis;
/*    */ import io.github.cottonmc.cotton.gui.widget.data.Insets;
/*    */ import me.shedaniel.autoconfig.AutoConfig;
/*    */ import me.shedaniel.math.Color;
/*    */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class Tooltip extends LightweightGuiDescription {
/* 18 */   private ModConfig config = (ModConfig)AutoConfig.getConfigHolder(ModConfig.class).getConfig(); public Tooltip(double speed, double jump, int health) {
/* 19 */     WBox root = new WBox(Axis.VERTICAL);
/* 20 */     setRootPanel((WPanel)root);
/* 21 */     root.setSpacing(-8);
/* 22 */     root.setInsets(new Insets(5, 5, 0, 5));
/*    */ 
/*    */     
/* 25 */     Color jumpColor = this.config.getNeutralColor();
/* 26 */     Color speedColor = this.config.getNeutralColor();
/* 27 */     Color hearthColor = this.config.getNeutralColor();
/* 28 */     if (this.config == null || this.config.useColors()) {
/* 29 */       if (jump > this.config.getGoodHorseJumpValue()) { jumpColor = this.config.getGoodColor(); }
/* 30 */       else if (jump < this.config.getBadHorseJumpValue()) { jumpColor = this.config.getBadColor(); }
/*    */       
/* 32 */       if (speed > this.config.getGoodHorseSpeedValue()) { speedColor = this.config.getGoodColor(); }
/* 33 */       else if (speed < this.config.getBadHorseSpeedValue()) { speedColor = this.config.getBadColor(); }
/*    */       
/* 35 */       if (health > this.config.getGoodHorseHeartsValue()) { hearthColor = this.config.getGoodColor(); }
/* 36 */       else if (health < this.config.getBadHorseHeartsValue()) { hearthColor = this.config.getBadColor(); }
/*    */     
/*    */     } 
/* 39 */     WBox speedBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 41 */     WLabel speedSymbol = new WLabel((class_2561)class_2561.method_43470("➟"), speedColor.hashCode());
/* 42 */     WLabel speedLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(speed)), speedColor.hashCode());
/*    */     
/* 44 */     speedBox.add((WWidget)speedSymbol);
/* 45 */     speedBox.add((WWidget)speedLabel);
/*    */     
/* 47 */     WBox jumpBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 49 */     WLabel jumpSymbol = new WLabel((class_2561)class_2561.method_43470("⇮"), jumpColor.hashCode());
/* 50 */     WLabel jumpLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(jump)), jumpColor.hashCode());
/*    */     
/* 52 */     jumpBox.add((WWidget)jumpSymbol);
/* 53 */     jumpBox.add((WWidget)jumpLabel);
/*    */     
/* 55 */     WBox healthBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 57 */     WLabel healthSymbol = new WLabel((class_2561)class_2561.method_43470("♥"), hearthColor.hashCode());
/* 58 */     WLabel healthLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(health)), hearthColor.hashCode());
/*    */     
/* 60 */     healthBox.add((WWidget)healthSymbol);
/* 61 */     healthBox.add((WWidget)healthLabel);
/*    */     
/* 63 */     root.add((WWidget)speedBox);
/* 64 */     root.add((WWidget)jumpBox);
/* 65 */     root.add((WWidget)healthBox);
/* 66 */     root.validate((GuiDescription)this);
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\gui\Tooltip.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */