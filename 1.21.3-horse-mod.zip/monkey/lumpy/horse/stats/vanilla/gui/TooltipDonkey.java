/*    */ package monkey.lumpy.horse.stats.vanilla.gui;
/*    */ import io.github.cottonmc.cotton.gui.client.LightweightGuiDescription;
/*    */ import io.github.cottonmc.cotton.gui.widget.WBox;
/*    */ import io.github.cottonmc.cotton.gui.widget.WLabel;
/*    */ import io.github.cottonmc.cotton.gui.widget.WPanel;
/*    */ import io.github.cottonmc.cotton.gui.widget.WWidget;
/*    */ import io.github.cottonmc.cotton.gui.widget.data.Axis;
/*    */ import io.github.cottonmc.cotton.gui.widget.data.Insets;
/*    */ import me.shedaniel.autoconfig.AutoConfig;
/*    */ import me.shedaniel.math.Color;
/*    */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class TooltipDonkey extends LightweightGuiDescription {
/* 18 */   private ModConfig config = (ModConfig)AutoConfig.getConfigHolder(ModConfig.class).getConfig(); public TooltipDonkey(double speed, double jump, int health, int strength) {
/* 19 */     WBox root = new WBox(Axis.VERTICAL);
/* 20 */     setRootPanel((WPanel)root);
/* 21 */     root.setSpacing(-8);
/* 22 */     root.setInsets(new Insets(5, 5, 0, 5));
/*    */ 
/*    */     
/* 25 */     Color jumpColor = this.config.getNeutralColor();
/* 26 */     Color speedColor = this.config.getNeutralColor();
/* 27 */     Color hearthColor = this.config.getNeutralColor();
/* 28 */     Color strengthColor = this.config.getNeutralColor();
/* 29 */     if (this.config == null || this.config.useColors()) {
/* 30 */       assert this.config != null;
/* 31 */       if (jump > this.config.getGoodHorseJumpValue()) { jumpColor = this.config.getGoodColor(); }
/* 32 */       else if (jump < this.config.getBadHorseJumpValue()) { jumpColor = this.config.getBadColor(); }
/*    */       
/* 34 */       if (speed > this.config.getGoodHorseSpeedValue()) { speedColor = this.config.getGoodColor(); }
/* 35 */       else if (speed < this.config.getBadHorseSpeedValue()) { speedColor = this.config.getBadColor(); }
/*    */       
/* 37 */       if (health > this.config.getGoodHorseHeartsValue()) { hearthColor = this.config.getGoodColor(); }
/* 38 */       else if (health < this.config.getBadHorseHeartsValue()) { hearthColor = this.config.getBadColor(); }
/*    */       
/* 40 */       if (strength > this.config.getGoodStrengthValue()) { strengthColor = this.config.getGoodColor(); }
/* 41 */       else if (strength < this.config.getBadStrengthValue()) { strengthColor = this.config.getBadColor(); }
/*    */     
/*    */     } 
/* 44 */     WBox speedBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 46 */     WLabel speedSymbol = new WLabel((class_2561)class_2561.method_43470("➟"), speedColor.hashCode());
/* 47 */     WLabel speedLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(speed)), speedColor.hashCode());
/*    */     
/* 49 */     speedBox.add((WWidget)speedSymbol);
/* 50 */     speedBox.add((WWidget)speedLabel);
/*    */     
/* 52 */     WBox jumpBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 54 */     WLabel jumpSymbol = new WLabel((class_2561)class_2561.method_43470("⇮"), jumpColor.hashCode());
/* 55 */     WLabel jumpLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(jump)), jumpColor.hashCode());
/*    */     
/* 57 */     jumpBox.add((WWidget)jumpSymbol);
/* 58 */     jumpBox.add((WWidget)jumpLabel);
/*    */     
/* 60 */     WBox healthBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 62 */     WLabel healthSymbol = new WLabel((class_2561)class_2561.method_43470("♥"), hearthColor.hashCode());
/* 63 */     WLabel healthLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(health)), hearthColor.hashCode());
/*    */     
/* 65 */     healthBox.add((WWidget)healthSymbol);
/* 66 */     healthBox.add((WWidget)healthLabel);
/*    */     
/* 68 */     WBox strengthBox = new WBox(Axis.HORIZONTAL);
/*    */     
/* 70 */     WLabel strengthSymbol = new WLabel((class_2561)class_2561.method_43470("▦"), strengthColor.hashCode());
/* 71 */     WLabel strengthLabel = new WLabel((class_2561)class_2561.method_43470(String.valueOf(strength)), strengthColor.hashCode());
/*    */     
/* 73 */     strengthBox.add((WWidget)strengthSymbol);
/* 74 */     strengthBox.add((WWidget)strengthLabel);
/*    */     
/* 76 */     root.add((WWidget)speedBox);
/* 77 */     root.add((WWidget)jumpBox);
/* 78 */     root.add((WWidget)healthBox);
/* 79 */     root.add((WWidget)strengthBox);
/* 80 */     root.validate((GuiDescription)this);
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\gui\TooltipDonkey.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */