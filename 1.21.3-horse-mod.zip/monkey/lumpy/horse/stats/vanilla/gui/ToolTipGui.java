/*    */ package monkey.lumpy.horse.stats.vanilla.gui;
/*    */ import io.github.cottonmc.cotton.gui.GuiDescription;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class ToolTipGui extends CottonClientScreen {
/*    */   public ToolTipGui(GuiDescription description) {
/*  9 */     super(description);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_25404(int ch, int keyCode, int modifiers) {
/* 14 */     if (keyCode == 26) {
/* 15 */       method_25419();
/*    */     }
/* 17 */     return super.method_25404(ch, keyCode, modifiers);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_16803(int ch, int keyCode, int modifiers) {
/* 22 */     if (keyCode == 50) {
/* 23 */       method_25419();
/*    */     }
/* 25 */     return super.method_16803(ch, keyCode, modifiers);
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\gui\ToolTipGui.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */