/*    */ package monkey.lumpy.horse.stats.vanilla;
/*    */ 
/*    */ import com.terraformersmc.modmenu.api.ConfigScreenFactory;
/*    */ import com.terraformersmc.modmenu.api.ModMenuApi;
/*    */ import me.shedaniel.autoconfig.AutoConfig;
/*    */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_437;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class ModMenuApiImpl
/*    */   implements ModMenuApi
/*    */ {
/*    */   public ConfigScreenFactory<?> getModConfigScreenFactory() {
/* 16 */     return parent -> (class_437)AutoConfig.getConfigScreen(ModConfig.class, parent).get();
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\ModMenuApiImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */