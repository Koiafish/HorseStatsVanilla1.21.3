/*    */ package monkey.lumpy.horse.stats.vanilla;
/*    */ import me.shedaniel.autoconfig.AutoConfig;
/*    */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class HorseStatsVanillaClient implements ClientModInitializer {
/*    */   public void onInitializeClient() {
/* 11 */     AutoConfig.register(ModConfig.class, me.shedaniel.autoconfig.serializer.JanksonConfigSerializer::new);
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\HorseStatsVanillaClient.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */