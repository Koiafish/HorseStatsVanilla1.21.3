/*    */ package monkey.lumpy.horse.stats.vanilla.util;
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class Converter {
/*    */   public static double jumpStrengthToJumpHeight(double strength) {
/*  5 */     double height = 0.0D;
/*  6 */     double velocity = strength;
/*  7 */     while (velocity > 0.0D) {
/*  8 */       height += velocity;
/*  9 */       velocity = (velocity - 0.08D) * 0.98D * 0.98D;
/*    */     } 
/* 11 */     return height;
/*    */   }
/*    */   
/*    */   public static double genericSpeedToBlocPerSec(double speed) {
/* 15 */     return 42.157796D * speed;
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanill\\util\Converter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */