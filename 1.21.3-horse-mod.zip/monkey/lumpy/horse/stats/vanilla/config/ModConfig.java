/*     */ package monkey.lumpy.horse.stats.vanilla.config;
/*     */ 
/*     */ import me.shedaniel.autoconfig.ConfigData;
/*     */ import me.shedaniel.autoconfig.annotation.Config;
/*     */ import me.shedaniel.autoconfig.annotation.ConfigEntry.Category;
/*     */ import me.shedaniel.autoconfig.annotation.ConfigEntry.ColorPicker;
/*     */ import me.shedaniel.autoconfig.annotation.ConfigEntry.Gui.Tooltip;
/*     */ import me.shedaniel.math.Color;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ 
/*     */ @Config(name = "horsestatsvanilla")
/*     */ @Environment(EnvType.CLIENT)
/*     */ public class ModConfig
/*     */   implements ConfigData
/*     */ {
/*     */   private boolean showValue = true;
/*     */   @Tooltip
/*     */   private boolean showMaxMin = false;
/*     */   @ColorPicker(allowAlpha = true)
/*  21 */   private int goodColor = -16731136; @Tooltip private boolean enableTooltip = true; private boolean valueUp = false; @Tooltip
/*     */   private boolean useColors = true; @ColorPicker(allowAlpha = true)
/*  23 */   private int neutralColor = -12171706;
/*     */   @ColorPicker(allowAlpha = true)
/*  25 */   private int badColor = -65536;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  28 */   private float goodHorseJumpValue = 4.0F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  31 */   private float badHorseJumpValue = 2.5F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  34 */   private float goodHorseSpeedValue = 11.0F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  37 */   private float badHorseSpeedValue = 7.0F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  40 */   private float goodHorseHeartsValue = 25.0F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  43 */   private float badHorseHeartsValue = 20.0F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  46 */   private float goodStrengthValue = 9.0F;
/*     */   @Category("coloring")
/*     */   @Tooltip
/*  49 */   private float badStrengthValue = 6.0F;
/*     */ 
/*     */   
/*     */   public boolean showValue() {
/*  53 */     return this.showValue;
/*     */   } public boolean useColors() {
/*  55 */     return this.useColors;
/*     */   } public boolean showMaxMin() {
/*  57 */     return this.showMaxMin;
/*     */   } public boolean valueUp() {
/*  59 */     return this.valueUp;
/*     */   }
/*     */   public boolean isTooltipEnabled() {
/*  62 */     return this.enableTooltip;
/*     */   }
/*     */   
/*     */   public float getGoodHorseJumpValue() {
/*  66 */     return this.goodHorseJumpValue;
/*     */   }
/*     */   
/*     */   public float getBadHorseJumpValue() {
/*  70 */     return this.badHorseJumpValue;
/*     */   }
/*     */   
/*     */   public float getGoodHorseSpeedValue() {
/*  74 */     return this.goodHorseSpeedValue;
/*     */   }
/*     */   
/*     */   public float getBadHorseSpeedValue() {
/*  78 */     return this.badHorseSpeedValue;
/*     */   }
/*     */   
/*     */   public float getGoodHorseHeartsValue() {
/*  82 */     return this.goodHorseHeartsValue;
/*     */   }
/*     */   
/*     */   public float getBadHorseHeartsValue() {
/*  86 */     return this.badHorseHeartsValue;
/*     */   }
/*     */   
/*     */   public float getGoodStrengthValue() {
/*  90 */     return this.goodStrengthValue;
/*     */   }
/*     */   
/*     */   public float getBadStrengthValue() {
/*  94 */     return this.badStrengthValue;
/*     */   }
/*     */   
/*     */   public Color getGoodColor() {
/*  98 */     return Color.ofOpaque(this.goodColor);
/*     */   }
/*     */   
/*     */   public Color getNeutralColor() {
/* 102 */     return Color.ofOpaque(this.neutralColor);
/*     */   }
/*     */   
/*     */   public Color getBadColor() {
/* 106 */     return Color.ofOpaque(this.badColor);
/*     */   }
/*     */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\config\ModConfig.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */