/*    */ package monkey.lumpy.horse.stats.vanilla.mixin.client;
/*    */ import io.github.cottonmc.cotton.gui.GuiDescription;
/*    */ import java.math.BigDecimal;
/*    */ import java.text.DecimalFormat;
/*    */ import me.shedaniel.autoconfig.AutoConfig;
/*    */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*    */ import monkey.lumpy.horse.stats.vanilla.gui.ToolTipGui;
/*    */ import monkey.lumpy.horse.stats.vanilla.gui.Tooltip;
/*    */ import monkey.lumpy.horse.stats.vanilla.util.Converter;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1496;
/*    */ import net.minecraft.class_1498;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1924;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_437;
/*    */ import net.minecraft.class_5134;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_1498.class})
/*    */ public abstract class HorseEntityMixin extends class_1496 {
/*    */   protected HorseEntityMixin(class_1299<? extends class_1496> entityType, class_1937 world) {
/* 32 */     super(entityType, world);
/*    */   }
/*    */   private ModConfig config;
/*    */   
/*    */   @Inject(at = {@At("HEAD")}, method = {"interactMob"})
/*    */   public class_1269 interactMob(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> ret) {
/* 38 */     if (this.config == null) {
/* 39 */       this.config = (ModConfig)AutoConfig.getConfigHolder(ModConfig.class).getConfig();
/*    */     }
/*    */     
/* 42 */     if (this.config.showValue() && !method_6727() && player.method_21823() && (this.config == null || this.config.isTooltipEnabled())) {
/*    */       
/* 44 */       DecimalFormat df = new DecimalFormat("#.#");
/* 45 */       String jumpStrength = df.format(Converter.jumpStrengthToJumpHeight(method_45325(class_5134.field_23728)));
/* 46 */       String maxHealth = df.format(method_6063());
/* 47 */       String speed = df.format(Converter.genericSpeedToBlocPerSec(method_6127().method_26852(class_5134.field_23719)));
/*    */       
/* 49 */       double jumpValue = (new BigDecimal(jumpStrength.replace(',', '.'))).doubleValue();
/* 50 */       double speedValue = (new BigDecimal(speed.replace(',', '.'))).doubleValue();
/* 51 */       int healthValue = (new BigDecimal(maxHealth.replace(',', '.'))).intValue();
/*    */       
/* 53 */       class_310.method_1551().execute(() -> class_310.method_1551().method_1507((class_437)new ToolTipGui((GuiDescription)new Tooltip(speedValue, jumpValue, healthValue))));
/*    */     } 
/*    */ 
/*    */     
/* 57 */     return (class_1269)ret.getReturnValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\mixin\client\HorseEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */