/*    */ package monkey.lumpy.horse.stats.vanilla.mixin.client;
/*    */ 
/*    */ import com.ibm.icu.math.BigDecimal;
/*    */ import com.ibm.icu.text.DecimalFormat;
/*    */ import io.github.cottonmc.cotton.gui.GuiDescription;
/*    */ import me.shedaniel.autoconfig.AutoConfig;
/*    */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*    */ import monkey.lumpy.horse.stats.vanilla.gui.ToolTipGui;
/*    */ import monkey.lumpy.horse.stats.vanilla.gui.TooltipDonkey;
/*    */ import monkey.lumpy.horse.stats.vanilla.util.Converter;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1492;
/*    */ import net.minecraft.class_1496;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1924;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_437;
/*    */ import net.minecraft.class_5134;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin({class_1492.class})
/*    */ public abstract class AbstractDonkeyEntityMixin extends class_1496 {
/*    */   private ModConfig config;
/*    */   
/*    */   protected AbstractDonkeyEntityMixin(class_1299<? extends class_1496> entityType, class_1937 world) {
/* 36 */     super(entityType, world);
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(at = {@At("HEAD")}, method = {"interactMob"})
/*    */   public class_1269 interactMob(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> ret) {
/* 42 */     if (this.config == null) {
/* 43 */       this.config = (ModConfig)AutoConfig.getConfigHolder(ModConfig.class).getConfig();
/*    */     }
/*    */     
/* 46 */     if (this.config.showValue() && !method_6727() && player.method_21823() && (this.config == null || this.config.isTooltipEnabled())) {
/*    */       
/* 48 */       DecimalFormat df = new DecimalFormat("#.#");
/* 49 */       String jumpStrength = df.format(Converter.jumpStrengthToJumpHeight(method_45325(class_5134.field_23728)));
/* 50 */       String maxHealth = df.format(method_6063());
/* 51 */       String strength = df.format(3L * method_6702());
/* 52 */       String speed = df.format(Converter.genericSpeedToBlocPerSec(method_6127().method_26852(class_5134.field_23719)));
/*    */       
/* 54 */       double jumpValue = (new BigDecimal(jumpStrength.replace(',', '.'))).doubleValue();
/* 55 */       double speedValue = (new BigDecimal(speed.replace(',', '.'))).doubleValue();
/* 56 */       int healthValue = (new BigDecimal(maxHealth.replace(',', '.'))).intValue();
/* 57 */       int strengthValue = (new BigDecimal(strength.replace(',', '.'))).intValue();
/*    */       
/* 59 */       class_310.method_1551().execute(() -> class_310.method_1551().method_1507((class_437)new ToolTipGui((GuiDescription)new TooltipDonkey(speedValue, jumpValue, healthValue, strengthValue))));
/*    */     } 
/*    */ 
/*    */     
/* 63 */     return (class_1269)ret.getReturnValue();
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   public abstract int method_6702();
/*    */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\mixin\client\AbstractDonkeyEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */