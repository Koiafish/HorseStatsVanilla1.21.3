/*     */ package monkey.lumpy.horse.stats.vanilla.mixin.client;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DecimalFormat;
/*     */ import me.shedaniel.autoconfig.AutoConfig;
/*     */ import me.shedaniel.math.Color;
/*     */ import monkey.lumpy.horse.stats.vanilla.config.ModConfig;
/*     */ import monkey.lumpy.horse.stats.vanilla.util.Converter;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.minecraft.class_1492;
/*     */ import net.minecraft.class_1496;
/*     */ import net.minecraft.class_1501;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1703;
/*     */ import net.minecraft.class_1724;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_465;
/*     */ import net.minecraft.class_491;
/*     */ import net.minecraft.class_5134;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ 
/*     */ @Environment(EnvType.CLIENT)
/*     */ @Mixin({class_491.class})
/*     */ public abstract class HorseScreenMixin extends class_465<class_1724> {
/*     */   @Shadow
/*     */   @Final
/*     */   private class_1496 field_2941;
/*     */   
/*     */   public HorseScreenMixin(class_1724 handler, class_1661 inventory, class_2561 title) {
/*  33 */     super((class_1703)handler, inventory, title);
/*     */   }
/*     */   private ModConfig config;
/*     */   protected void method_2388(class_332 drawContext, int mouseX, int mouseY) {
/*  37 */     super.method_2388(drawContext, mouseX, mouseY);
/*  38 */     if (this.config == null) {
/*  39 */       this.config = (ModConfig)AutoConfig.getConfigHolder(ModConfig.class).getConfig();
/*     */     }
/*  41 */     if (this.config.showValue()) {
/*  42 */       boolean hasChest = (class_1492.class.isAssignableFrom(this.field_2941.getClass()) && ((class_1492)this.field_2941).method_6703());
/*  43 */       DecimalFormat df = new DecimalFormat("#.#");
/*  44 */       String jumpStrength = df.format(Converter.jumpStrengthToJumpHeight(this.field_2941.method_45325(class_5134.field_23728)));
/*  45 */       String maxHealth = df.format(this.field_2941.method_6063());
/*  46 */       String speed = df.format(Converter.genericSpeedToBlocPerSec(this.field_2941.method_6127().method_26852(class_5134.field_23719)));
/*     */ 
/*     */       
/*  49 */       Color jumpColor = this.config.getNeutralColor();
/*  50 */       Color speedColor = this.config.getNeutralColor();
/*  51 */       Color hearthColor = this.config.getNeutralColor();
/*  52 */       if (this.config.useColors()) {
/*  53 */         double jumpValue = (new BigDecimal(jumpStrength.replace(',', '.'))).doubleValue();
/*  54 */         double speedValue = (new BigDecimal(speed.replace(',', '.'))).doubleValue();
/*  55 */         double healthValue = (new BigDecimal(maxHealth.replace(',', '.'))).doubleValue();
/*     */         
/*  57 */         if (jumpValue > this.config.getGoodHorseJumpValue()) { jumpColor = this.config.getGoodColor(); }
/*  58 */         else if (jumpValue < this.config.getBadHorseJumpValue()) { jumpColor = this.config.getBadColor(); }
/*     */         
/*  60 */         if (speedValue > this.config.getGoodHorseSpeedValue()) { speedColor = this.config.getGoodColor(); }
/*  61 */         else if (speedValue < this.config.getBadHorseSpeedValue()) { speedColor = this.config.getBadColor(); }
/*     */         
/*  63 */         if (healthValue > this.config.getGoodHorseHeartsValue()) { hearthColor = this.config.getGoodColor(); }
/*  64 */         else if (healthValue < this.config.getBadHorseHeartsValue()) { hearthColor = this.config.getBadColor(); }
/*     */       
/*     */       } 
/*  67 */       if (this.config.valueUp()) {
/*  68 */         drawContext.method_51433(this.field_22793, "➟ " + speed, 87, 6, speedColor.hashCode(), false);
/*  69 */         drawContext.method_51433(this.field_22793, "⇮ " + jumpStrength, 122, 6, jumpColor.hashCode(), false);
/*  70 */         drawContext.method_51433(this.field_22793, "♥ " + maxHealth, 147, 6, hearthColor.hashCode(), false);
/*  71 */         if (this.config.showMaxMin()) {
/*  72 */           drawContext.method_51433(this.field_22793, "➟ (4.7-14.2)", 180, 30, this.config.getNeutralColor().hashCode(), false);
/*  73 */           drawContext.method_51433(this.field_22793, "⇮ (1-5.3)", 180, 40, this.config.getNeutralColor().hashCode(), false);
/*  74 */           drawContext.method_51433(this.field_22793, "♥ (15-30)", 180, 50, this.config.getNeutralColor().hashCode(), false);
/*     */         } 
/*  76 */       } else if (!hasChest) {
/*  77 */         if (this.config.showMaxMin()) {
/*  78 */           drawContext.method_51433(this.field_22793, "(4.7-14.2)", 119, 26, this.config.getNeutralColor().hashCode(), false);
/*  79 */           drawContext.method_51433(this.field_22793, "(1-5.3)", 119, 36, this.config.getNeutralColor().hashCode(), false);
/*  80 */           drawContext.method_51433(this.field_22793, "(15-30)", 119, 46, this.config.getNeutralColor().hashCode(), false);
/*     */         } 
/*  82 */         drawContext.method_51433(this.field_22793, "➟", 82, 26, speedColor.hashCode(), false);
/*  83 */         drawContext.method_51433(this.field_22793, speed, 93, 26, speedColor.hashCode(), false);
/*  84 */         drawContext.method_51433(this.field_22793, "⇮", 84, 36, jumpColor.hashCode(), false);
/*  85 */         drawContext.method_51433(this.field_22793, jumpStrength, 93, 36, jumpColor.hashCode(), false);
/*  86 */         drawContext.method_51433(this.field_22793, "♥", 83, 46, hearthColor.hashCode(), false);
/*  87 */         drawContext.method_51433(this.field_22793, maxHealth, 93, 46, hearthColor.hashCode(), false);
/*     */       } else {
/*  89 */         drawContext.method_51433(this.field_22793, "➟ " + speed, 80, 6, speedColor.hashCode(), false);
/*  90 */         drawContext.method_51433(this.field_22793, "⇮ " + jumpStrength, 115, 6, jumpColor.hashCode(), false);
/*  91 */         drawContext.method_51433(this.field_22793, "♥ " + maxHealth, 140, 6, hearthColor.hashCode(), false);
/*     */       } 
/*     */       
/*  94 */       Color strengthColor = this.config.getNeutralColor();
/*     */       
/*  96 */       if (class_1501.class.isAssignableFrom(this.field_2941.getClass())) {
/*  97 */         int strength = 3 * ((class_1501)this.field_2941).method_6803();
/*     */         
/*  99 */         if (this.config.useColors())
/* 100 */           if (strength > this.config.getGoodHorseJumpValue()) { strengthColor = this.config.getGoodColor(); }
/* 101 */           else if (strength < this.config.getBadHorseJumpValue()) { strengthColor = this.config.getBadColor(); }
/*     */            
/* 103 */         if (!hasChest)
/* 104 */           if (this.config.valueUp()) {
/* 105 */             drawContext.method_51433(this.field_22793, "▦ " + strength, 62, 6, strengthColor.hashCode(), false);
/*     */           } else {
/* 107 */             drawContext.method_51433(this.field_22793, "▦", 83, 56, strengthColor.hashCode(), false);
/* 108 */             drawContext.method_51433(this.field_22793, String.valueOf(strength), 93, 56, strengthColor.hashCode(), false);
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\troop\OneDrive\Desktop\horse-stats-vanilla-4.8.0.jar!\monkey\lumpy\horse\stats\vanilla\mixin\client\HorseScreenMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */